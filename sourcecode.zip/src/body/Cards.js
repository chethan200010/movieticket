import React from "react";
import './card.css';
import {useNavigate} from "react-router-dom";




function Card(props){
    const navigate = useNavigate();
    const gotoSElection = () =>{
        navigate("/MainBooking")
    };
    return(
        <>
    
        <div className="Cards" >
           <div className="card">
               <img src={props.imgsrc} alt="mypic" className="card_img"  />
                <div className="card_info"  >
                  <span className="card_category"> {props.title}</span>
                   <h3 className="card_title"> {props.sname}</h3>
                    <a><button onClick={() =>gotoSElection()}>Book Now</button></a>   
                </div>
             </div>
        </div>
        </>

    )
};
export default Card;