import React from "react";
import Card from "./Cards";

function Body() {
  return (
    <>
      <h1 className="heading_style">Newly Released Movies</h1>
      <Card
        imgsrc="https://images-eu.ssl-images-amazon.com/images/S/pv-target-images/7ced95368eb89af9ee93f6b2b6bb3d400a6be38024eac30f99f58abded933948._UR1920,1080_RI_SX356_FMwebp_.jpg"
        title="Sandalwood Best Movie"
        sname="K.G.F" />
      <Card
        imgsrc="https://tse1.mm.bing.net/th?id=OIP.VkSEiLU0SJes7QL_TtpsaQHaF3&pid=Api&P=0&w=212&h=167"
        title="Telugu Hit"
        sname="PUSHPA" />

      <Card
        imgsrc="https://tse3.mm.bing.net/th?id=OIP.IZJv8P3Qi1j2l5eq-UjssAHaEK&pid=Api&P=0&w=323&h=181"
        title="Kannada Love Hit"
        sname="Love Mocktail 2" />




    </>
  )
};
export default Body;