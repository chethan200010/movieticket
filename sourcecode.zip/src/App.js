import React from "react";
import{
    BrowserRouter as Router,
    Routes,
    Route
    
    } from "react-router-dom";
     import Body from "./body/Body";
    import MainBooking from "./MainBooking";
    import SeatBooking from "./pages/SeatBooking";
    
    
    function App(){
        return(
            <>
           
            <Router>
            <Routes>
            <Route exact path="/" element={<Body/>}/>
            <Route exact path="/MainBooking" element={<MainBooking/>}/>
            <Route exact path="/Body" element={<Body/>}/>
            <Route exact path="/SeatBooking" element={<SeatBooking/>}/>
            
           </Routes>   
            </Router>
            
            </>
        );
    }
    export default App;
